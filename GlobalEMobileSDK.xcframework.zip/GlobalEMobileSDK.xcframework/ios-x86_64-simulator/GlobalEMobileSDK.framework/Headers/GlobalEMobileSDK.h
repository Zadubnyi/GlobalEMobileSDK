//
//  GlobalEMobileSDK.h
//  GlobalEMobileSDK
//
//  Created by Vitalii Zadubnyi on 07.04.2020.
//  Copyright © 2020 Global-e. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for GlobalEMobileSDK.
FOUNDATION_EXPORT double GlobalEMobileSDKVersionNumber;

//! Project version string for GlobalEMobileSDK.
FOUNDATION_EXPORT const unsigned char GlobalEMobileSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <GlobalEMobileSDK/PublicHeader.h>


